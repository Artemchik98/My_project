from django.apps import AppConfig


class EcomappConfig(AppConfig):
    name = 'ecomapp'
