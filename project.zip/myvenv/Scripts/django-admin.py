#!E:\STYDY\ВЕБ_технологии_И_дезигн\ODZ\myvenv\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
